CREATE PROCEDURE `pro_upload_movies`(`_Vname`  TEXT, `_Vinfo` LONGTEXT, `_Vpic` LONGBLOB, `_Vsrc` TEXT, `_id` INT(11),
                                     `_mytype` VARCHAR(50), `_Vdirector` LONGTEXT, `_Vactor` LONGTEXT)
  begin
	insert into
	_type(Tid)
	values(_mytype);
	insert into 
	movies(Vname,Vinfo,Vpic,Vsrc,id,Vdate)
	values(_Vname,_Vinfo,_Vpic,_Vsrc,_id,now());
	insert into 
	review(Vdirector,Vactor)
	values(_Vdirector,_Vactor);
end