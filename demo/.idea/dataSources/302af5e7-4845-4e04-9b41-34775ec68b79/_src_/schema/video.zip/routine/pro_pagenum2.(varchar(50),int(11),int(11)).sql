CREATE PROCEDURE `pro_pagenum2`(`txt` VARCHAR(50), `cur_page` INT(11), `Uid` INT(11))
  begin	
    if Uid = -1 then
		#1.为游客设置默认的每页的行数end
		set row_num:= 8;
	else 
		#2.为用户所对应的行数赋值end
		select pagenum into row_num 
		from user
		where id = Uid;
    end if;    
	#3.总的电影数量end
    select count(*) into row_total
    from movies m
    join _type t on(t.Vid=m.Vid)
    join review r on(r.Vid=m.Vid)
    where m.Vinfo like txt or t.Tid like txt or m.Vname like txt or r.Vdirector like txt or r.Vactor like txt;
    #4.计算总页数end
    set page_total := ceil(row_total / row_num);
    #5.查询出每页的具体电影个数，依据分页公式（(cur_page-1)*page_num）end
    #因为要用字符串来执行多以公式中就不能有变量，就得把公式分出来算完在与字符串集合end
    set @select_str0:= ' select * from movies m join user u on(m.id=u.id) join _type t on(t.Vid=m.Vid) join review r on(r.Vid=m.Vid)';    
    set @where_str1:= ' where Vinfo like ';    
    set @where_str2:= ' or Vname like ';
    set @where_str3:= ' or t.Tid like ';
    set @where_str4:= ' or r.Vdirector like ';
    set @where_str5:= ' or r.Vactor like ';
    set @order_str:= ' order by m.Vid desc limit ';
    set @select_str:= concat(@select_str0,@where_str1,''',txt,''',@where_str2,''',txt,''',@where_str3,''',txt,''',@where_str4,''',txt,''',@where_str5,''',txt,''',@order_str);
    #6.算出limit 行数的开始行号end
    set @limit_str:= (cur_page-1)*row_num;
    #row_num:是每页的电影数量end
    set @sql_str = concat(@select_str,@limit_str,',',row_num);
    #准备语句end
    prepare ps from @sql_str;
    #执行语句end
    execute ps;
end