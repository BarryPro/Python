CREATE PROCEDURE `pro_pagenum3`(`Uid` INT(11), `a_Vid` INT(11), `cur_page` INT(11))
  begin
#1.查找每页的行数end
if Uid = -1 then
	set a_pagenum:=8;
else 
	select pagenum into a_pagenum
	from user
	where id = Uid;
end if;
#2.查询总行数用于分页end
select count(*) into row_total
from article
where Vid = a_Vid;
#3.计算总页数end
set page_total := ceil(row_total / a_pagenum);
#4.分页核心公式end.根据电影id查处有关的评论end
set @limit_str:=(cur_page - 1) * a_pagenum;
set @where_vid:= a_Vid;
set @limit_vid:= " limit ";
set @select_str:="select * from article a join user u on(a.Uid=u.id) where Vid = ";
set @order_aid:=" order by a.Aid desc ";
set @sql_str:= concat(@select_str,@where_vid,@order_aid,@limit_vid,@limit_str,',',a_pagenum);
prepare ps from @sql_str;
execute ps;
end