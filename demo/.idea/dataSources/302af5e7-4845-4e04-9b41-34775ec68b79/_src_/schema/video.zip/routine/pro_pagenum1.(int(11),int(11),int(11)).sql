CREATE PROCEDURE `pro_pagenum1`(`Vtype` INT(11), `cur_page` INT(11), `Uid` INT(11))
  begin
	if Uid = -1 then
		#1.为游客设置默认的每页的行数end
		set row_num:= 8;
	else 
		#2.为用户所对应的行数赋值end
		select pagenum into row_num 
		from user
		where id = Uid;
    end if;    
    if Vtype = 0 then
		#3.总的电影数量end
		select count(*) into row_total
		from _type
		where Tid < 5;
        #5.查询出每页的具体电影个数，依据分页公式（(cur_page-1)*page_num）end
		#因为要用字符串来执行多以公式中就不能有变量，就得把公式分出来算完在与字符串集合end
        set @select_str:= 'select * from movies m join user u on(m.id=u.id) join _type t on(t.Vid=m.Vid) where Tid < 5 order by m.Vid desc limit ';
	else 
		select count(*) into row_total
		from _type
		where Tid = Vtype;
        set @select_str1:= 'select * from movies m join user u on(m.id=u.id) join _type t on(t.Vid=m.Vid) where t.Tid = ';
        set @select_str2:= ' order by m.Vid desc limit ';
        set @select_str:= concat(@select_str1,Vtype,@select_str2);
    end if;	
    #4.计算总页数end
    set page_total := ceil(row_total / row_num); 
    #6.算出limit 行数的开始行号end
    set @limit_str:= (cur_page-1)*row_num;
    #row_num:是每页的电影数量end
    set @sql_str = concat(@select_str,@limit_str,',',row_num);
    #准备语句end
    prepare ps from @sql_str;
    #执行语句end
    execute ps;
end